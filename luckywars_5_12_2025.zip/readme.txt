3D Artist:
- Falanta (Discord @falanta, falantafantomo@gmail.com)

Internet materials:

# Textures
Explosive : https://modrinth.com/mod/explosive-enhancement
Ribbits : https://modrinth.com/mod/ribbits
Swords : https://www.curseforge.com/minecraft/texture-packs/unique-swords
Magical stick texture: https://modrinth.com/resourcepack/magic-debug-stick
Mana : https://www.planetminecraft.com/texture-pack/manahunger-1-21/
Bows :
  -  https://www.planetminecraft.com/texture-pack/hunter-s-bow/
  -  https://www.planetminecraft.com/texture-pack/better-bow/
Gems : https://www.planetminecraft.com/texture-pack/enchanted-gems-5532558/
Enchanted books: https://www.curseforge.com/minecraft/texture-packs/xalis-enchanted-books/
GUI base: https://modrinth.com/resourcepack/gui-revision

Sounds used from:
 - Garry's mod
 - Ultrakill
 - Team Fortress 2

# Shaders
Animated unicode : https://github.com/JNNGL/vanilla-shaders/tree/main
Diamonds in the Sky: https://www.planetminecraft.com/texture-pack/diamonds-in-the-sky/


Resource pack by 2M3V (Discord @2m3v, mentusik02316@gmail.com)
Build: 5 Dec 2025