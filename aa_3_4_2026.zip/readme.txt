Sounds used from games:
 - Half-life
 - Team Fortress 2
 - Team Fortress 2 Classified
 - Pizza Tower
 - BABBDI
 - TearDown

Special thanks DartCat25 (https://www.planetminecraft.com/texture-pack/3d-breaking-particles/)

Resource pack by 2M3V (Discord @2m3v, mentusik02316@gmail.com)




























repis 8-)
Build: 3 Apr 2026