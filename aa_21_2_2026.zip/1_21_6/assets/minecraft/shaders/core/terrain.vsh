#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

vec4 minecraft_sample_lightmap(sampler2D lightMap, ivec2 uv) {
    return texture(lightMap, clamp(uv / 256.0, vec2(0.5 / 16.0), vec2(15.5 / 16.0)));
}

void main() {
    vec3 pos = Position + ModelOffset;

	vec4 color = texture(Sampler0, UV0);
	// https://github.com/McTsts/mc-core-shaders/blob/main/wavy%20water/rendertype_translucent.vsh
	// wavy water
	if(Color.r < 0.4 && Color.r > 0.1 && Color.b > 0.2 && color.a < 0.8 && color.a > 0.4 && color.b == color.g && color.g == color.r && Color.r != Color.b) { // identify water
		// options
		float waveSize = 2.0; // determines wave size
		float waveHeight = 15.0; // height
		// calculation
		float timer = GameTime * 2000.0; // game time, determines amount of waves
		float offset = sin(round(pos.x / waveSize) + timer) - cos(round(pos.z / waveSize) + timer); // calculate offset
		pos = pos + vec3(0.0, offset / waveHeight - 0.025, 0.0);
	}

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = Color * minecraft_sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}
