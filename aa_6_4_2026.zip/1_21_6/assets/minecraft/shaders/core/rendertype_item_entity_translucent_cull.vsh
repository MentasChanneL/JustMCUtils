#version 150

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;
out vec4 filterColor;
out vec4 lightFace;

void main() {
    filterColor = Color;
    lightFace = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    vec3 pos = Position;
    vec4 rgb = floor(Color * 255.0);
    
    vec4 finalColor;
    if (rgb.r == 249.0) {
        pos.z += 120.0 * (mod(GameTime * 20000 + 1.2 * rgb.g, 200.0) / 200.0);
        finalColor = vec4(1);
    } else if (rgb.r == 248.0 && rgb.g == 1.0) {
        finalColor = vec4(1.0, 1.0, 1.0, Color.b);
    } else {
        finalColor = Color;
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal + vec3(0.3), finalColor) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;
    
    if (Color.a < 0.8) vertexColor = vec4(0);
}
