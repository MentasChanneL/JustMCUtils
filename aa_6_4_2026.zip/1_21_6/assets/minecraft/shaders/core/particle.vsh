#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec2 UV0;
in vec4 Color;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec2 texCoord0;
out vec4 vertexColor;

void main() {
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    texCoord0 = UV0;
    float alphaFloor = floor(Color.a * 4.0) / 4.0;
    vertexColor = vec4(Color.rgb, alphaFloor) * texelFetch(Sampler2, UV2 / 16, 0);

    vec2 texSize = textureSize(Sampler0, 0); 
    vec2 uv = UV0 * texSize;
    uv.x -= mod(uv.x, 8);
    uv.y -= mod(uv.y, 8);
    vec4 cornerColor = texture(Sampler0, (uv + 0.5) / texSize);
    if(cornerColor.r == 250.0/255.0 && cornerColor.g == 1.0 && cornerColor.b == 1.0) {
        gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
        return;
    }

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    // Thanks DartCat25 (https://www.planetminecraft.com/texture-pack/3d-breaking-particles/)
    ivec2 texSize1 = textureSize(Sampler0, 0);
    vec2 uv1 = (UV0 * texSize1);

    if (floor(uv1) != uv1 && texSize1.y / texSize1.x != 4) {
        vertexColor = vec4(0);
    }
}
