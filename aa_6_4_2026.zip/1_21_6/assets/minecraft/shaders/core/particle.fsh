#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    ivec3 rgb = ivec3(texture(Sampler0, texCoord0) * 255.0);
    float alpha = color.a;
    if (rgb.r == 251 && rgb.g == 250 && rgb.b == 255) {
        if (vertexColor.a < 0.7) alpha = 0.0;
    }
    fragColor = apply_fog(vec4(color.rgb, alpha), sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
